﻿angular.module('accessnowapp')
.controller('shared-controller', ['$scope', function ($scope) {

}]);