﻿angular.module('accessnowapp')
.controller('vps-controller', ['$scope', function ($scope) {

}]);