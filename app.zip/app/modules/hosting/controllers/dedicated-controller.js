﻿angular.module('accessnowapp')
.controller('dedicated-controller', ['$scope', function ($scope) {

}]);