﻿angular.module('accessnowapp')
.controller('host-about-controller', ['$scope', function ($scope) {

}]);