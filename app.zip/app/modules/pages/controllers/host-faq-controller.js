﻿angular.module('accessnowapp')
.controller('host-faq-controller', ['$scope', function ($scope) {

}]);