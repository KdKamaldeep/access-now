﻿angular.module('accessnowapp')
.controller('support-controller', ['$scope', function ($scope) {

}]);