﻿angular.module('accessnowapp')
.controller('host-data-controller', ['$scope', function ($scope) {
   
}]);