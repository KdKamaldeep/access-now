﻿angular.module('accessnowapp')
.controller('blog-controller', ['$scope', function ($scope) {

}]);