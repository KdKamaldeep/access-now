﻿angular.module('accessnowapp')
.controller('blog-detail-controller', ['$scope', function ($scope) {

}]);