﻿(function () {
    'use strict';
    angular.module('accessnowapp')
    .controller('hosted-domain-controller', ['$scope', 'domainService', function ($scope, domainService) {


    }]);
})();