﻿angular.module('accessnowapp')
.controller('main-controller', ['$scope', function ($scope) {

}]);