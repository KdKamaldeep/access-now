﻿(function () {


    'use strict';
    angular.module('accessnowapp')
    .controller('thankyou-controller', ['$scope',
        function ($scope) {


        }]);
})();
