[ ![Codeship Status for bobstermyang/access-now](https://codeship.com/projects/746939d0-3dff-0133-60ae-7ed35fdf0bd9/status?branch=master)](https://codeship.com/projects/102651)

# ShotLocal-Web-Hosting

Install Node first from https://nodejs.org
Open command propmpt and cd to working directory and Run `npm install`

## Run `bower install`

## Build & development

Run `grunt` for building and `grunt serve` for preview.

## Testing

Running `grunt test` will run the unit tests with karma.

Enjoy